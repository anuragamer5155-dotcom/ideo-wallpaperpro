# Video Live Wallpaper Pro

A lightweight Android app that lets you set any video from your phone as a live wallpaper — on home screen, lock screen, or both.

## Features

- Pick any video from phone storage
- Set video as live wallpaper (home, lock, or both screens)
- Full-screen preview before applying
- Mute/unmute video audio
- Crop to fill or fit to screen
- Auto-loops seamlessly
- Pauses when screen is off to save battery
- Resumes when screen turns on
- ExoPlayer for hardware-accelerated playback
- Optimized for low-end devices
- Modern dark Material Design 3 UI
- MVVM architecture

## File Structure

```
video-live-wallpaper-pro/
├── app/
│   ├── build.gradle.kts                    # App-level Gradle config
│   ├── proguard-rules.pro                  # ProGuard rules for release builds
│   └── src/main/
│       ├── AndroidManifest.xml             # App manifest with permissions & services
│       ├── java/com/videowallpaper/pro/
│       │   ├── service/
│       │   │   └── VideoWallpaperService.kt  # Live wallpaper engine (ExoPlayer)
│       │   ├── ui/
│       │   │   ├── MainActivity.kt           # Main screen (select, preview, apply)
│       │   │   └── PreviewActivity.kt        # Full-screen video preview
│       │   ├── viewmodel/
│       │   │   └── MainViewModel.kt          # MVVM ViewModel for state management
│       │   └── util/
│       │       ├── PermissionHelper.kt       # Runtime permission handling
│       │       └── PreferenceManager.kt      # SharedPreferences wrapper
│       └── res/
│           ├── drawable/                     # Launcher icon vectors
│           ├── layout/
│           │   ├── activity_main.xml         # Main screen layout
│           │   ├── activity_preview.xml      # Preview screen layout
│           │   └── dialog_apply_options.xml  # Apply wallpaper bottom sheet
│           ├── mipmap-*/                     # Adaptive icon definitions
│           ├── values/
│           │   ├── colors.xml                # Dark theme color palette
│           │   ├── strings.xml               # All string resources
│           │   └── themes.xml                # Material 3 dark theme
│           └── xml/
│               └── wallpaper.xml             # Wallpaper service metadata
├── build.gradle.kts                         # Root Gradle config
├── settings.gradle.kts                      # Project settings
├── gradle.properties                        # Gradle properties
└── gradle/wrapper/
    └── gradle-wrapper.properties            # Gradle wrapper version
```

## Technical Details

| Property        | Value                          |
|-----------------|--------------------------------|
| Min SDK         | 21 (Android 5.0 Lollipop)     |
| Target SDK      | 34 (Android 14)               |
| Language         | Kotlin                         |
| Architecture     | MVVM                           |
| Video Player     | ExoPlayer (Media3)             |
| UI Framework     | Material Design 3 + ViewBinding|
| Build System     | Gradle Kotlin DSL              |

## Setup Instructions

### Prerequisites

1. **Android Studio** Hedgehog (2023.1.1) or newer
2. **JDK 17** (bundled with Android Studio)
3. **Android SDK 34** installed via SDK Manager

### Step-by-Step Setup

1. **Download the project**
   - Download the entire `video-live-wallpaper-pro` folder from this workspace

2. **Open in Android Studio**
   - Launch Android Studio
   - Click **File > Open**
   - Select the `video-live-wallpaper-pro` folder
   - Wait for Gradle sync to complete (may take 1-2 minutes on first open)

3. **Verify SDK**
   - Go to **File > Project Structure > Project**
   - Ensure Gradle version is **8.5** and AGP is **8.2.2**
   - Go to **SDK Location** and verify Android SDK path

4. **Run on Device/Emulator**
   - Connect an Android device via USB (enable Developer Options & USB Debugging)
   - Or create an emulator via **Device Manager** (API 30+ recommended)
   - Click the green **Run** button or press `Shift+F10`

### Build APK

**Debug APK:**
```bash
./gradlew assembleDebug
```
APK location: `app/build/outputs/apk/debug/app-debug.apk`

**Release APK (signed):**

1. Generate a keystore:
```bash
keytool -genkey -v -keystore release-key.jks -keyalg RSA -keysize 2048 -validity 10000 -alias my-key
```

2. Add to `gradle.properties`:
```properties
RELEASE_STORE_FILE=release-key.jks
RELEASE_STORE_PASSWORD=your_password
RELEASE_KEY_ALIAS=my-key
RELEASE_KEY_PASSWORD=your_password
```

3. Add signing config to `app/build.gradle.kts`:
```kotlin
android {
    signingConfigs {
        create("release") {
            storeFile = file(project.property("RELEASE_STORE_FILE") as String)
            storePassword = project.property("RELEASE_STORE_PASSWORD") as String
            keyAlias = project.property("RELEASE_KEY_ALIAS") as String
            keyPassword = project.property("RELEASE_KEY_PASSWORD") as String
        }
    }
    buildTypes {
        release {
            signingConfig = signingConfigs.getByName("release")
        }
    }
}
```

4. Build:
```bash
./gradlew assembleRelease
```
APK location: `app/build/outputs/apk/release/app-release.apk`

### Build AAB (for Google Play)
```bash
./gradlew bundleRelease
```
AAB location: `app/build/outputs/bundle/release/app-release.aab`

## How to Use the App

1. **Open the app** — you see the dark-themed main screen
2. **Tap "Select Video"** — picks a video from your phone
3. **Tap "Preview"** — see the video full-screen exactly how it will look as wallpaper
4. **Toggle Mute/Unmute** — control whether the wallpaper plays audio
5. **Toggle Crop/Fit** — choose whether the video fills the screen (cropped) or fits within it (letterboxed)
6. **Tap "Apply Wallpaper"** — choose Home Screen, Lock Screen, or Both
7. **Confirm** in the system dialog — Android requires confirmation for live wallpapers

## Performance Optimizations

- **ExoPlayer** with hardware-accelerated decoding
- **Screen off detection** — player pauses when display turns off
- **Visibility tracking** — player pauses when wallpaper is not visible
- **Minimal memory footprint** — no background services when wallpaper is inactive
- **ProGuard** enabled for release builds (minification + shrinking)
- **Video scaling modes** use GPU for crop/fit transformations

## Permissions

| Permission | Purpose | Android Version |
|---|---|---|
| `READ_EXTERNAL_STORAGE` | Access videos | API 21-32 |
| `READ_MEDIA_VIDEO` | Access videos | API 33+ |
| `BIND_WALLPAPER` | Live wallpaper service | All |

## Troubleshooting

- **Video not playing as wallpaper**: Make sure you confirmed the wallpaper in the system dialog
- **Permission denied**: Go to Settings > Apps > Video Live Wallpaper Pro > Permissions and grant storage access
- **Battery drain**: The app pauses playback when the screen is off; short videos (under 30 seconds) work best
- **Video looks stretched**: Toggle the Crop/Fit button before applying
