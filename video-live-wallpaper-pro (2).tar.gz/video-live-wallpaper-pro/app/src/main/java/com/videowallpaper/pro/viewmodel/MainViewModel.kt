package com.videowallpaper.pro.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import com.videowallpaper.pro.util.PreferenceManager

// ViewModel for managing UI state following MVVM pattern
class MainViewModel(application: Application) : AndroidViewModel(application) {

    private val _videoUri = MutableLiveData<Uri?>()
    val videoUri: LiveData<Uri?> = _videoUri

    private val _isMuted = MutableLiveData<Boolean>()
    val isMuted: LiveData<Boolean> = _isMuted

    private val _isCropMode = MutableLiveData<Boolean>()
    val isCropMode: LiveData<Boolean> = _isCropMode

    private val _statusMessage = MutableLiveData<String>()
    val statusMessage: LiveData<String> = _statusMessage

    init {
        // Load saved preferences
        val context = application.applicationContext
        _videoUri.value = PreferenceManager.getVideoUri(context)
        _isMuted.value = PreferenceManager.isMuted(context)
        _isCropMode.value = PreferenceManager.isCropMode(context)
    }

    // Set the selected video URI and persist it
    fun setVideoUri(uri: Uri) {
        _videoUri.value = uri
        PreferenceManager.saveVideoUri(getApplication(), uri)
    }

    // Toggle mute state
    fun toggleMute() {
        val newState = !(_isMuted.value ?: true)
        _isMuted.value = newState
        PreferenceManager.setMuted(getApplication(), newState)
    }

    // Toggle crop/fit mode
    fun toggleCropMode() {
        val newState = !(_isCropMode.value ?: true)
        _isCropMode.value = newState
        PreferenceManager.setCropMode(getApplication(), newState)
    }

    // Update status message shown to user
    fun setStatus(message: String) {
        _statusMessage.value = message
    }
}
