package com.videowallpaper.pro.service

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Matrix
import android.graphics.Paint
import android.net.Uri
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.service.wallpaper.WallpaperService
import android.util.Log
import android.view.SurfaceHolder
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import com.videowallpaper.pro.util.PreferenceManager

// WallpaperService implementation that renders video as live wallpaper
// Uses ExoPlayer for efficient video playback with hardware acceleration
class VideoWallpaperService : WallpaperService() {

    override fun onCreateEngine(): Engine {
        return VideoEngine()
    }

    inner class VideoEngine : Engine() {

        private var player: ExoPlayer? = null
        private val handler = Handler(Looper.getMainLooper())
        private var isVisible = false
        private var videoUri: Uri? = null

        // BroadcastReceiver to pause/resume on screen on/off
        private val screenReceiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context?, intent: Intent?) {
                when (intent?.action) {
                    Intent.ACTION_SCREEN_OFF -> pausePlayer()
                    Intent.ACTION_SCREEN_ON -> if (isVisible) resumePlayer()
                }
            }
        }

        override fun onCreate(surfaceHolder: SurfaceHolder?) {
            super.onCreate(surfaceHolder)

            // Register screen on/off receiver to save battery
            val filter = IntentFilter().apply {
                addAction(Intent.ACTION_SCREEN_OFF)
                addAction(Intent.ACTION_SCREEN_ON)
            }
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                applicationContext.registerReceiver(
                    screenReceiver, filter, Context.RECEIVER_NOT_EXPORTED
                )
            } else {
                applicationContext.registerReceiver(screenReceiver, filter)
            }
        }

        override fun onSurfaceCreated(holder: SurfaceHolder?) {
            super.onSurfaceCreated(holder)
            initializePlayer(holder)
        }

        override fun onSurfaceChanged(
            holder: SurfaceHolder?,
            format: Int,
            width: Int,
            height: Int
        ) {
            super.onSurfaceChanged(holder, format, width, height)
        }

        override fun onSurfaceDestroyed(holder: SurfaceHolder?) {
            super.onSurfaceDestroyed(holder)
            releasePlayer()
        }

        override fun onVisibilityChanged(visible: Boolean) {
            super.onVisibilityChanged(visible)
            isVisible = visible
            if (visible) {
                // Reload preferences in case they changed
                loadPreferences()
                resumePlayer()
            } else {
                pausePlayer()
            }
        }

        override fun onDestroy() {
            super.onDestroy()
            releasePlayer()
            try {
                applicationContext.unregisterReceiver(screenReceiver)
            } catch (e: Exception) {
                Log.w(TAG, "Receiver already unregistered", e)
            }
        }

        // Initialize ExoPlayer with optimized settings
        private fun initializePlayer(holder: SurfaceHolder?) {
            if (holder == null) return

            videoUri = PreferenceManager.getVideoUri(applicationContext)
            if (videoUri == null) {
                // Draw a black screen if no video is set
                drawBlackScreen(holder)
                return
            }

            handler.post {
                try {
                    // Create ExoPlayer with performance optimizations
                    player = ExoPlayer.Builder(applicationContext)
                        .build()
                        .apply {
                            // Set video to render on the wallpaper surface
                            setVideoSurfaceHolder(holder)

                            // Enable looping
                            repeatMode = Player.REPEAT_MODE_ALL

                            // Apply mute setting
                            val isMuted = PreferenceManager.isMuted(applicationContext)
                            volume = if (isMuted) 0f else 1f

                            // Set video scaling based on crop preference
                            val isCrop = PreferenceManager.isCropMode(applicationContext)
                            videoScalingMode = if (isCrop) {
                                androidx.media3.common.C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                            } else {
                                androidx.media3.common.C.VIDEO_SCALING_MODE_SCALE_TO_FIT
                            }

                            // Prepare and play
                            val mediaItem = MediaItem.fromUri(videoUri!!)
                            setMediaItem(mediaItem)
                            prepare()
                            playWhenReady = isVisible
                        }
                } catch (e: Exception) {
                    Log.e(TAG, "Error initializing player", e)
                    drawBlackScreen(holder)
                }
            }
        }

        // Load preferences and apply to running player
        private fun loadPreferences() {
            handler.post {
                player?.let { p ->
                    val newUri = PreferenceManager.getVideoUri(applicationContext)
                    val isMuted = PreferenceManager.isMuted(applicationContext)
                    val isCrop = PreferenceManager.isCropMode(applicationContext)

                    // Update mute state
                    p.volume = if (isMuted) 0f else 1f

                    // Update scaling mode
                    p.videoScalingMode = if (isCrop) {
                        androidx.media3.common.C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
                    } else {
                        androidx.media3.common.C.VIDEO_SCALING_MODE_SCALE_TO_FIT
                    }

                    // If video URI changed, reload the media
                    if (newUri != null && newUri != videoUri) {
                        videoUri = newUri
                        p.setMediaItem(MediaItem.fromUri(newUri))
                        p.prepare()
                        p.playWhenReady = true
                    }
                }
            }
        }

        // Pause player to save resources
        private fun pausePlayer() {
            handler.post {
                player?.playWhenReady = false
            }
        }

        // Resume player
        private fun resumePlayer() {
            handler.post {
                player?.playWhenReady = true
            }
        }

        // Release player resources
        private fun releasePlayer() {
            handler.post {
                player?.release()
                player = null
            }
        }

        // Draw a black screen as fallback
        private fun drawBlackScreen(holder: SurfaceHolder) {
            try {
                val canvas: Canvas? = holder.lockCanvas()
                canvas?.let {
                    it.drawColor(Color.BLACK)
                    holder.unlockCanvasAndPost(it)
                }
            } catch (e: Exception) {
                Log.w(TAG, "Error drawing black screen", e)
            }
        }
    }

    companion object {
        private const val TAG = "VideoWallpaperService"
    }
}
