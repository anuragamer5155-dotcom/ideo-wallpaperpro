package com.videowallpaper.pro.ui

import android.net.Uri
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import com.videowallpaper.pro.databinding.ActivityPreviewBinding
import com.videowallpaper.pro.util.PreferenceManager

// Preview Activity - shows full-screen video preview before applying wallpaper
// Uses ExoPlayer for smooth playback matching the actual wallpaper experience
class PreviewActivity : AppCompatActivity() {

    private lateinit var binding: ActivityPreviewBinding
    private var player: ExoPlayer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityPreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnBack.setOnClickListener {
            finish()
        }

        val uriString = intent.getStringExtra(EXTRA_VIDEO_URI) ?: return finish()
        initializePlayer(Uri.parse(uriString))
    }

    // Initialize ExoPlayer for preview
    private fun initializePlayer(uri: Uri) {
        player = ExoPlayer.Builder(this).build().apply {
            // Attach to the PlayerView
            binding.playerView.player = this

            // Set looping
            repeatMode = Player.REPEAT_MODE_ALL

            // Apply mute/volume setting from preferences
            val isMuted = PreferenceManager.isMuted(this@PreviewActivity)
            volume = if (isMuted) 0f else 1f

            // Apply crop/fit setting
            val isCrop = PreferenceManager.isCropMode(this@PreviewActivity)
            videoScalingMode = if (isCrop) {
                androidx.media3.common.C.VIDEO_SCALING_MODE_SCALE_TO_FIT_WITH_CROPPING
            } else {
                androidx.media3.common.C.VIDEO_SCALING_MODE_SCALE_TO_FIT
            }

            // Set resize mode on the PlayerView to match
            binding.playerView.resizeMode = if (isCrop) {
                androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_ZOOM
            } else {
                androidx.media3.ui.AspectRatioFrameLayout.RESIZE_MODE_FIT
            }

            // Load and play the video
            setMediaItem(MediaItem.fromUri(uri))
            prepare()
            playWhenReady = true
        }
    }

    override fun onPause() {
        super.onPause()
        player?.playWhenReady = false
    }

    override fun onResume() {
        super.onResume()
        player?.playWhenReady = true
    }

    override fun onDestroy() {
        super.onDestroy()
        player?.release()
        player = null
    }

    companion object {
        const val EXTRA_VIDEO_URI = "extra_video_uri"
    }
}
