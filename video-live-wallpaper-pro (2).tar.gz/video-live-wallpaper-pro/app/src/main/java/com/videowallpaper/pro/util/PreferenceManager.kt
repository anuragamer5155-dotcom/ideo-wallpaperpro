package com.videowallpaper.pro.util

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri

// Manages app preferences for persisting user settings
object PreferenceManager {

    private const val PREF_NAME = "video_wallpaper_prefs"
    private const val KEY_VIDEO_URI = "video_uri"
    private const val KEY_IS_MUTED = "is_muted"
    private const val KEY_IS_CROP = "is_crop"

    private fun getPrefs(context: Context): SharedPreferences {
        return context.getSharedPreferences(PREF_NAME, Context.MODE_PRIVATE)
    }

    // Save the selected video URI
    fun saveVideoUri(context: Context, uri: Uri) {
        getPrefs(context).edit().putString(KEY_VIDEO_URI, uri.toString()).apply()
    }

    // Get the saved video URI
    fun getVideoUri(context: Context): Uri? {
        val uriString = getPrefs(context).getString(KEY_VIDEO_URI, null)
        return uriString?.let { Uri.parse(it) }
    }

    // Save mute preference
    fun setMuted(context: Context, muted: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_IS_MUTED, muted).apply()
    }

    // Get mute preference
    fun isMuted(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_IS_MUTED, true)
    }

    // Save crop/fit preference (true = crop to fill, false = fit to screen)
    fun setCropMode(context: Context, crop: Boolean) {
        getPrefs(context).edit().putBoolean(KEY_IS_CROP, crop).apply()
    }

    // Get crop/fit preference
    fun isCropMode(context: Context): Boolean {
        return getPrefs(context).getBoolean(KEY_IS_CROP, true)
    }
}
