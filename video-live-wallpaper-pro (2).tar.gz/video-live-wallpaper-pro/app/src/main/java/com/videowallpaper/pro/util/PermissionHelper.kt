package com.videowallpaper.pro.util

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import androidx.core.content.ContextCompat

// Helper class for managing runtime permissions
object PermissionHelper {

    // Get the appropriate storage permission based on Android version
    fun getStoragePermission(): String {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            Manifest.permission.READ_MEDIA_VIDEO
        } else {
            Manifest.permission.READ_EXTERNAL_STORAGE
        }
    }

    // Check if storage permission is granted
    fun hasStoragePermission(context: Context): Boolean {
        val permission = getStoragePermission()
        return ContextCompat.checkSelfPermission(context, permission) ==
                PackageManager.PERMISSION_GRANTED
    }
}
