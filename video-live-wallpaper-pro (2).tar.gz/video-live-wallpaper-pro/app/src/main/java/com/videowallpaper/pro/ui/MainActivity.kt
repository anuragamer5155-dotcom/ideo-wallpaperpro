package com.videowallpaper.pro.ui

import android.app.WallpaperManager
import android.content.ComponentName
import android.content.Intent
import android.graphics.Bitmap
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.videowallpaper.pro.R
import com.videowallpaper.pro.databinding.ActivityMainBinding
import com.videowallpaper.pro.databinding.DialogApplyOptionsBinding
import com.videowallpaper.pro.service.VideoWallpaperService
import com.videowallpaper.pro.util.PermissionHelper
import com.videowallpaper.pro.util.PreferenceManager
import com.videowallpaper.pro.viewmodel.MainViewModel

// Main Activity - entry point of the app
// Handles video selection, preview navigation, and wallpaper application
class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private val viewModel: MainViewModel by viewModels()

    // Permission request launcher
    private val permissionLauncher = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            openVideoPicker()
        } else {
            Toast.makeText(this, R.string.permission_required, Toast.LENGTH_LONG).show()
        }
    }

    // Video picker launcher using SAF (Storage Access Framework)
    private val videoPickerLauncher = registerForActivityResult(
        ActivityResultContracts.OpenDocument()
    ) { uri: Uri? ->
        uri?.let {
            // Take persistent permission so the wallpaper service can access it
            contentResolver.takePersistableUriPermission(
                it,
                Intent.FLAG_GRANT_READ_URI_PERMISSION
            )
            viewModel.setVideoUri(it)
            viewModel.setStatus(getString(R.string.video_selected))
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupObservers()
        setupClickListeners()
    }

    // Observe ViewModel state changes and update UI
    private fun setupObservers() {
        viewModel.videoUri.observe(this) { uri ->
            if (uri != null) {
                binding.tvNoVideo.visibility = android.view.View.GONE
                binding.ivThumbnail.visibility = android.view.View.VISIBLE
                loadThumbnail(uri)
            } else {
                binding.tvNoVideo.visibility = android.view.View.VISIBLE
                binding.ivThumbnail.visibility = android.view.View.GONE
            }
        }

        viewModel.isMuted.observe(this) { muted ->
            binding.btnMute.text = if (muted) getString(R.string.unmute) else getString(R.string.mute)
        }

        viewModel.isCropMode.observe(this) { crop ->
            binding.btnCropFit.text = if (crop) getString(R.string.fit_screen) else getString(R.string.crop_screen)
        }

        viewModel.statusMessage.observe(this) { message ->
            binding.tvStatus.text = message
        }
    }

    // Set up button click listeners
    private fun setupClickListeners() {
        binding.btnSelectVideo.setOnClickListener {
            if (PermissionHelper.hasStoragePermission(this)) {
                openVideoPicker()
            } else {
                permissionLauncher.launch(PermissionHelper.getStoragePermission())
            }
        }

        binding.btnPreview.setOnClickListener {
            val uri = viewModel.videoUri.value
            if (uri != null) {
                val intent = Intent(this, PreviewActivity::class.java).apply {
                    putExtra(PreviewActivity.EXTRA_VIDEO_URI, uri.toString())
                }
                startActivity(intent)
            } else {
                Toast.makeText(this, R.string.select_video_first, Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnApplyWallpaper.setOnClickListener {
            if (viewModel.videoUri.value != null) {
                showApplyOptions()
            } else {
                Toast.makeText(this, R.string.select_video_first, Toast.LENGTH_SHORT).show()
            }
        }

        binding.btnMute.setOnClickListener {
            viewModel.toggleMute()
        }

        binding.btnCropFit.setOnClickListener {
            viewModel.toggleCropMode()
        }
    }

    // Open system video picker using SAF
    private fun openVideoPicker() {
        try {
            videoPickerLauncher.launch(arrayOf("video/*"))
        } catch (e: Exception) {
            Toast.makeText(this, "Unable to open video picker", Toast.LENGTH_SHORT).show()
        }
    }

    // Load video thumbnail from URI
    private fun loadThumbnail(uri: Uri) {
        try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(this, uri)
            val bitmap: Bitmap? = retriever.getFrameAtTime(
                1000000, // 1 second into video
                MediaMetadataRetriever.OPTION_CLOSEST_SYNC
            )
            retriever.release()
            bitmap?.let {
                binding.ivThumbnail.setImageBitmap(it)
            }
        } catch (e: Exception) {
            binding.ivThumbnail.setImageResource(android.R.color.darker_gray)
        }
    }

    // Show bottom sheet dialog with wallpaper apply options
    private fun showApplyOptions() {
        val dialog = BottomSheetDialog(this, R.style.Theme_VideoWallpaper)
        val dialogBinding = DialogApplyOptionsBinding.inflate(layoutInflater)
        dialog.setContentView(dialogBinding.root)

        dialogBinding.btnApplyHome.setOnClickListener {
            dialog.dismiss()
            applyWallpaper(WallpaperManager.FLAG_SYSTEM)
        }

        dialogBinding.btnApplyLock.setOnClickListener {
            dialog.dismiss()
            applyWallpaper(WallpaperManager.FLAG_LOCK)
        }

        dialogBinding.btnApplyBoth.setOnClickListener {
            dialog.dismiss()
            applyWallpaper(WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK)
        }

        dialog.show()
    }

    // Apply the video as a live wallpaper
    // Note: Android requires user confirmation for live wallpapers via system UI
    private fun applyWallpaper(flags: Int) {
        try {
            viewModel.setStatus(getString(R.string.applying_wallpaper))

            // Launch the system live wallpaper picker
            // The user must confirm setting the live wallpaper
            val intent = Intent(WallpaperManager.ACTION_CHANGE_LIVE_WALLPAPER).apply {
                putExtra(
                    WallpaperManager.EXTRA_LIVE_WALLPAPER_COMPONENT,
                    ComponentName(
                        this@MainActivity,
                        VideoWallpaperService::class.java
                    )
                )
            }
            startActivity(intent)
            viewModel.setStatus(getString(R.string.wallpaper_applied))
        } catch (e: Exception) {
            // Fallback to legacy wallpaper picker
            try {
                val intent = Intent(WallpaperManager.ACTION_LIVE_WALLPAPER_CHOOSER)
                startActivity(intent)
            } catch (e2: Exception) {
                Toast.makeText(this, R.string.wallpaper_failed, Toast.LENGTH_SHORT).show()
                viewModel.setStatus(getString(R.string.wallpaper_failed))
            }
        }
    }
}
